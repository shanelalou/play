//RANDOM!!


 function fact2(){
 
var a="Can you feel the pulse in your wrist? For humans the normal pulse is 70 heartbeats per minute.";
var b="In one day your heart beats 100,000 times.";
var c="Half your body�s red blood cells are replaced every seven days";
var d="By the time you are 70 you will have easily drunk over 12,000 gallons of water.";
var e="Coughing can cause air to move through your windpipe faster than the speed of sound � over a thousand feet per second!";
var f="It takes more muscles to frown than it does to smile.";
var g="It takes food seven seconds to go from the mouth to the stomach via the esophagus.";
var h="A human�s small intestine is 6 meters long.";
var i="The human body is 75% water";
var j="Your blood takes a very long trip through your body. If you could stretch out all of a human�s blood vessels, they would be about 60,000 miles long. That�s enough to go around the world twice.";
var k="The strongest bone in your body is the femur (thighbone), and it�s hollow!";
var l="The width of your armspan stretched out is the length of your whole body.";
var m="The average human dream lasts only 2 to 3 seconds.";
var n="The average person has at least seven dreams a night.";
var o="Your brain is move active and thinks more at night than during the day.";
var p="Your brain is 80% water.";
var q="85% of the population can curl their tongue into a tube.";
var r="Your tongue has 3,000 taste buds.";
var s="Your forearm (from inside of elbow to inside of wrist) is the same length as your foot.";
var t="Your thigh bone is stronger than concrete.";
var u="You blink your eyes over 10,000,000 a year.";
var v="Your fingernails grow almost four times as fast as your toenails.";
var w="There were about 300 bones in your body when you were born, but by the time you reach adulthood you only have 206.";
var x="Your mouth uses 75 muscles when you speak!";
var y="When you wake up in the morning you are at taller than when you go to sleep, because you have let your spine straighten back out after all the bending, sitting, and moving you have done!";
var z="The average growth of hair is half an inch per month.";
var none="It is impossible to sneeze with your eyes open.";
var cream=[a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z];
  	var rice=Math.floor(Math.random()*26);
  	var vinegar=cream[rice];
  	
  	document.getElementById("txtresult2").value=vinegar
  	var result = 	document.getElementById("txtresult2");
 result.style.fontSize = "50px",
 document.getElementById("txtresult2").style.color="blue";
  	

  	
  }