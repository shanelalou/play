
// ANIMALS!!


 function fact1(){
 

var a="Half of the world's chameleon species lives in Madagascar.";
var b="The fastest bird in the world is the Peregrine Falcon";
var c="The largest bird egg in the world today is that of the ostrich.";
var d="The only poisonous birds in the world are the three species of Pitohui.";
var e="The tallest mammal in the world is the giraffe.";
var f="A duck's quack does echo, despite rumors to the contrary";
var g="Cats urine glows under a black light.";
var h="A pig's orgasm lasts for 30 minutes.";
var i="Humans and horses are the only two animals that have hymens.";
var j="Humans, dolphins and apes are the only mammals that have sex for pleasure.";
var k="A shark is the only fish that can blink with both eyes.";
var l="There are more chickens than people in the world.";
var m="A cat has 32 muscles in each ear";
var n="An ostrich's eye is bigger than its brain.";
var o="Tigers have striped skin, not just striped fur.";
var p="A mayfly only lives a few minutes to a few days, depending on the species.";
var q="A goldfish has a memory span of three months. (source).";
var r="The giant squid has the largest eyes in the world.";
var s=" A turkey can drown if it looks up while it's raining. ";


var none="Please type a question then ask again";
var cream=[a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s];
  	var rice=Math.floor(Math.random()*19);
  	var vinegar=cream[rice];
  	
  	document.getElementById("txtresult1").value=vinegar
  	var result = 	document.getElementById("txtresult1");
 result.style.fontSize = "50px",
 document.getElementById("txtresult1").style.color="Blue";
  	
//,s,t,u,v,w,x,y,z
  	
  }