//RANDOM!!


 function fact(){
 
var a="The coconut is the largest seed in the world.";
var b="The anaconda, one of the world's largest snakes, gives birth to its young instead of laying eggs.";
var c="The only country in the world that has a Bill of Rights for Cows is India";
var d="Monopoly is the best-selling board game in the world";
var e="After chocolate and vanilla, orange is considered the world's most favorite flavor";
var f="The rarest coffee in the world is Kopi Luwak, which is found in Indonesia";
var g="The coconut is the largest seed in the world";
var h="Finland has the greatest number of islands in the world, 179,584";
var i="Black pepper is the most popular spice in the world";
var j="Panama is the only place in the world where one can see the sun rise on the Pacific Ocean and set on the Atlantic.";
var k="Millions of trees in the world are accidentally planted by squirrels who bury nuts and then forget where they hid them ";
var l="Eighty percent of the world's rose species come from Asia.";
var m="The world's rarest gem is Painite";
var n="Belize is the only country in the world with a jaguar preserve.";
var o="The Hope diamond is the biggest blue diamond known in the world.";
var p="The name Jeep came from the abbreviation used in the army for the General Purpose vehicle, GP ";
var q="The first toilet ever seen on television was on Leave It To Beaver";
var r="One of the longest one-syllable words in the English language is screeched. (Strengths is another one.)";
var s="No word in the English language rhymes with month, orange, silver or purple.";
var t="'Dreamt� is the only English word that ends in the letters �mt�";
var u="There are only four words in the English language which end in '-dous' tremendous, horrendous, stupendous, and hazardous. ";
var v="Typing the word typewriter uses only letters from the top row of your keyboard.";
var w="Porcupines float in water. ";
var x="Checkmate comes from the Persian phrase 'shah mat' which means the king is dead";
var y="Peanuts are one of the ingredients of dynamite.";
var z="Rubber bands last longer when refrigerated ";
var none="Almonds are a member of the peach family";
var cream=[a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z];
  	var rice=Math.floor(Math.random()*26);
  	var vinegar=cream[rice];
  	
  	document.getElementById("txtresult").value=vinegar
  	var result = 	document.getElementById("txtresult");
 result.style.fontSize = "50px",
 document.getElementById("txtresult").style.color="blue";
  	

  	
  }