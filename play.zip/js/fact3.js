//RANDOM!!\


 function fact3(){
 
var a="The fastest bird is the peregrine falcon. It can fly at a speed of 168-217 miles per hour.";
var b="The deadliest disease was the pneumonic form of the Black Death of 1347-1351. It had death rate of 100%.";
var c="The largest egg laid by a living bird is that of the North African Ostrich. It is 6 to 8 inches in length and 4 to 6 inches in diameter. The smallest is that of the hummingbird. It is less than 0.39 inches in diameter.";
var d="The hottest continent on earth is Africa, where a record high of 136.4 degrees F was once recorded.";
var e="Antarctica is the coldest continent on earth, where a temperature of 126.9 degrees F below zero was once recorded. Chicago is home to three of the five tallest buildings in the world � the Sears Tower, Standard Oil Building, and John Hancock Center.";
var f="The hottest place on earth is in Dallol, Ethiopia, which is a sizzling 94 degrees in the shade on a typical day!";
var g="Angel Falls in Venezuela is 20 times taller than Niagara Falls.";
var h="The blue whale is the largest animal that ever lived (it could reach 100 feet long and weight up to 150 tons!)";
var i="The longest bout of hiccups lasted 69 years!";
var j="The smallest cat is the Singapuras and weighs only 4 pounds.";
var k="The strongest bone in your body is the femur (thighbone), and it�s hollow!";
var l="The longest movie made lasts 85 hours and is fittingly titled �The Cure for Insomnia.�";
var m="Did you know that there is a world record for seeing how many times you can attempt a world record?!";
var n="The largest baby to be born so far weighed in at 15 pounds, 5 ounces!";
var o="The longest recorded flight of a chicken is thirteen seconds.";
var p="Your brain is 80% water.";
var q="85% of the population can curl their tongue into a tube.";
var r="Your tongue has 3,000 taste buds.";
var s="Your forearm (from inside of elbow to inside of wrist) is the same length as your foot.";
var t="Your thigh bone is stronger than concrete.";
var u="You blink your eyes over 10,000,000 a year.";
var v="Your fingernails grow almost four times as fast as your toenails.";
var w="There were about 300 bones in your body when you were born, but by the time you reach adulthood you only have 206.";
var x="Your mouth uses 75 muscles when you speak!";
var y="When you wake up in the morning you are at taller than when you go to sleep, because you have let your spine straighten back out after all the bending, sitting, and moving you have done!";
var z="The average growth of hair is half an inch per month.";
var none="It is impossible to sneeze with your eyes open.";
var cream=[a,b,c,d,e,f,g,h,i,j,k,l,m,n,o];
  	var rice=Math.floor(Math.random()*13);
  	var vinegar=cream[rice];
  	
  	document.getElementById("txtresult3").value=vinegar
  	var result = 	document.getElementById("txtresult3");
 result.style.fontSize = "50px",
 document.getElementById("txtresult3").style.color="blue";
  	

  	//,p,q,r,s,t,u,v,w,x,y,z
  }